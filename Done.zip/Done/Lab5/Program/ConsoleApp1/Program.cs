﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using DLLView;



namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            View.Interface();
        }
    }
}
